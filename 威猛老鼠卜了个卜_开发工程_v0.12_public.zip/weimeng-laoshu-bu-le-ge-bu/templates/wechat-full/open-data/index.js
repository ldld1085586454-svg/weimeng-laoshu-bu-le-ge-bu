'use strict';
require('./renderer');
